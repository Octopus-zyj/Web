package webadv.s99201105.p02;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
import org.apache.commons.codec.digest.DigestUtils;
public class App {

	private static String name;
	private static String password;
	static Scanner input=new Scanner(System.in);
    public static void main(String[] args) {
//        if (args.length < 1) {
//            System.err.println("Please provide an input!");
//            System.exit(0);
//        }
//        System.out.println(sha256hex(args[0]));
        System.out.println("please input your name and password");
    	name = input.next();
    	password = input.next();
    	if(name.equals("zyj") && password.equals("123456")) {
    		System.out.println(name);
    		sha256hex(password);
    		System.out.println("login success");
    	}else {
    		System.out.println(name);
    		sha256hex(password);
    		System.out.println("failed!");
    	}
    }
    
    public static String sha256hex(String input) {
        return DigestUtils.sha256Hex(input);
    }
}

